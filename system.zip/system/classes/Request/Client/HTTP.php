<?php defined('SYSPATH') OR die('No direct script access.');

class Request_Client_HTTP extends Kohana_Request_Client_HTTP {}
